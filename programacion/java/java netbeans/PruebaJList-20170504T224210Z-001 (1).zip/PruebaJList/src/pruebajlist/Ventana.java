
package pruebajlist;

import Conexion.ConexionBD;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class Ventana extends JFrame implements ListSelectionListener
{
    private Container contenedor;
    private JPanel panel;
    private JList<Object> lista;
    private JTextArea texto;
    private JScrollPane scroll;
    private final Object[] listado;
    public Ventana ()
    {
        contenedor = getContentPane();
        panel = new JPanel(new BorderLayout(10,4));
        ConexionBD conexion = new ConexionBD();
        listado = conexion.correosRecibidos();
        lista = new JList<>(listado);
        lista.addListSelectionListener(this);
        scroll = new JScrollPane(lista);
        texto = new JTextArea(25,40);
        panel.add(scroll,BorderLayout.WEST);
        panel.add(texto,BorderLayout.EAST);
        contenedor.add(panel);  
        
        this.setTitle("correo");
        this.setSize(240,320);
        this.pack();
        this.setVisible(true);

    }

    @Override
    public void valueChanged(ListSelectionEvent e) 
    {
        if(e.getValueIsAdjusting())
        {
            int indice = lista.getSelectedIndex();
            texto.setText((String)listado[indice]);
        }
    }
}