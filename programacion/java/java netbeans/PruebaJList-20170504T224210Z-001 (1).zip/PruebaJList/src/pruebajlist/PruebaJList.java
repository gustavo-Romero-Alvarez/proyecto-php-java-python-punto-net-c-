
package pruebajlist;

public class PruebaJList 
{
    public static void main(String[] args) 
    {
        //new Ventana().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        new Conexion.ConexionBD();
    }    
}
