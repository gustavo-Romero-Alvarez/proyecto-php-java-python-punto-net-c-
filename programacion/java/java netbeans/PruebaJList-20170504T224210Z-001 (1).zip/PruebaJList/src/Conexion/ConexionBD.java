
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConexionBD 
{
    private String cadenaConexion = "jdbc:oracle:thin:@localhost:1521:XE";
    private Connection conexion;
    
    public ConexionBD()
    {
        try 
        {
            conexion = null;            
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conexion = DriverManager.getConnection(cadenaConexion,"fcandia","123");
            System.out.println("Conexion exitosa... =D ");
        } 
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Clase drive oracle no encontrada");
        }
        catch (SQLException ex) 
        {
            System.out.println("Error de conexion. Verifique usuario y/o contraseña...");
        }
    }
    
    public Object[] correosRecibidos()
    {   
        Object[] resultado = new Object[20];
        int indice = 0;
        
        try 
        {
            String consulta = "SELECT remitente FROM contenido";
            Statement instruccionBaseDatos = conexion.createStatement();
            ResultSet datos = instruccionBaseDatos.executeQuery(consulta);
            while(datos.next())
            {
                Object dato = datos.getString("REMITENTE");
                resultado [indice] = dato;
                indice++;
            }
        } 
        catch (SQLException ex) 
        {
            System.out.println("Error al crear la instruccion de base de datos...");
        }
        return resultado;
    }
}